﻿using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Open the Submit Claim Window
            SubmitClaimWindow submitClaimWindow = new SubmitClaimWindow();
            submitClaimWindow.ShowDialog();
        }

        private void btnViewStatus_Click(object sender, RoutedEventArgs e)
        {
            // Placeholder for viewing claim status functionality
            MessageBox.Show("View Claim Status functionality is not implemented yet.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnApproveClaims_Click(object sender, RoutedEventArgs e)
        {
            // Open the Approve Claims Window
            ApproveClaimsWindow approveClaimsWindow = new ApproveClaimsWindow();
            approveClaimsWindow.ShowDialog();
        }

        private void btnUploadDocuments_Click(object sender, RoutedEventArgs e)
        {
            // Open the Upload Documents Window
            UploadDocumentsWindow uploadDocumentsWindow = new UploadDocumentsWindow();
            uploadDocumentsWindow.ShowDialog();
        }
    }
}

